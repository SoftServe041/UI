import React from 'react';
import logo from './logo.png';
import './main_page/main_page.css';

function App() {
  return (
    /*
    <div className="App">
      <header className="App-header">
        <img src={logo} alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
    */
   <div>
     <header className="Main-header">
       <div className="Div-image">
         <a href="/">
       <img src={logo} className="Logo" alt="logo"  />
       </a></div>
     
       <div className="Div-Menu" id="TopNav">
         <a className="a" href="/#">
         <h2 className="h2">About Us</h2>
       </a>
       </div>

       <div className="Div-Login" id="TopNav">
       <a className="a" href="/#">
         <h2 className="h2">LogIn</h2>
       </a>
       </div>

       <div className="Div-Login" >

         <h2 className="h2">|</h2>

       </div>

       <div className="Div-Login" id="TopNav">
       <a className="a" href="/#">
         <h2 className="h2">SignUp</h2>
       </a>
       </div>
       
       </header>
   </div>
  );
}

export default App;
